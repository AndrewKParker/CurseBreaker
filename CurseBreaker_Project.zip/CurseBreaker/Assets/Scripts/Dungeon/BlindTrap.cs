﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlindTrap : MonoBehaviour {

	public static int triggered = 0;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		// Get the position of the player
		Vector3 playerPos = GameObject.Find ("Player(Clone)").transform.position;
		// Get the position of the Staircase
		Vector3 thisTrap = transform.position;
		if (triggered == 0){
			if (thisTrap == playerPos) {
				PlayerStatus.isBlind = true;
				triggered = 1;
			}
		
		}
	}
}
