﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeepPlayer : MonoBehaviour {

	void Awake() {
		DontDestroyOnLoad (transform.gameObject);
	}
}
