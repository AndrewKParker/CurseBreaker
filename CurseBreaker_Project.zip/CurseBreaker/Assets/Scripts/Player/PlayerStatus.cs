﻿using System.Collections;
using UnityEngine.UI;
using UnityEngine;

public class PlayerStatus : MonoBehaviour {

	public int playerLvl = 1;				// Default level
	public int playerHP = 100;				// Default health
	public int maxHP = 100;
	public int playerAP = 10;				// Default ability points
	public int maxAP = 10;
	public int curseBuildup = 0;			// Default curse buildup
	public int playerVit = 5;				// Default vitality
	public int playerStr = 7;				// Default strength
	public int playerDef = 5;				// Default defense
	public int playerMnd = 4;				// Default mind
	public int playerLuc = 0;				// Default luck
	public int expCurrent = 0;				// Default experience points

	public bool isApa	= false;			// Apathetic ailment. Halves turns.
	public bool isBind	= false;			// Bind ailment. Can't move but can take other actions.
	public static bool isBlind = false;		// Blind ailment. Vision is obscured.
	public bool isBurn = false;				// Burn ailment. Take damage over time. Water can treat it.
	public bool isFroz = false;				// Frozen ailment. Can't move. Take damage. Damage can treat it.
	public bool isSleep = false;			// Sleep ailment. Can't move. Damage can treat it.
	public bool isCurse = false;			// Curse ailment. Curse gain is increased.
	public bool isParal = false;			// Paralysis ailment. Can't move.
	public bool isPoison = false;			// Poison ailment. Take damage.

	public int ailStr	= 0;				// Ailment strength determines legnth of affliction

	public string playerName;				// The player's name
	public string playerClass;				// The player's class

	public Text fieldText1;
	public Text fieldText2;
	public Text fieldText3;
	public Text fieldText4;

	void Awake ()
	{
		int currentHP = playerHP;				// Set the current health of the player to their playerHP
		int currentAP = playerAP;				// Set the current ability points of the player to their playerAP

		//print (currentHP);
		//print (currentAP);

		fieldText1 = GameObject.Find("PlayerLevelText").GetComponent<Text>();
		fieldText2 = GameObject.Find("PlayerHPText").GetComponent<Text>();
		fieldText3 = GameObject.Find("PlayerAPText").GetComponent<Text>();
		fieldText4 = GameObject.Find ("PlayerCurseText").GetComponent<Text> ();

		//print (currentHP);
		//print (currentAP);

		fieldText1.text = "Level: " + playerLvl;
		fieldText2.text = "HP: " + currentHP + "/" + maxHP;
		fieldText3.text = "AP: " + currentAP + "/" + maxAP;
		fieldText4.text = "Curse: " + curseBuildup + "%";
	}

	void Update ()
	{
		if(Input.GetKey("z")){
			isBlind = false;
			GameObject.Find ("Blind Icon").GetComponent<Image> ().enabled = false;
			BlindTrap.triggered = 0;
		}
		if (isBlind == true) {
			GameObject.Find ("Light").GetComponent<SpriteRenderer> ().enabled = true;
			GameObject.Find ("Blind Icon").GetComponent<Image> ().enabled = true;
		}
		else
			GameObject.Find ("Light").GetComponent<SpriteRenderer>().enabled = false;
	}
}