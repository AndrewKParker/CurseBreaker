﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Movement : MonoBehaviour {

	float speed = 2.0f;
	// declare an Animator variable
	Animator anim;
	// declare a Vector3 variable
	Vector3 pos;
	// declare a Transform variable
	Transform tr;
	// determines the player direction during collision
	public int dir;
	//public GameObject tObj;
	public bool pTurn = true;

	// Use this for initialization
	void Start () {
		pos = transform.position;
		tr = transform;

		//tObj = GameObject.Find("GameManager");
		//print (tObj);
		// the animator varible
		anim = GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		//pTurn = tObj.GetComponent<bool>(playersTurn);
		// Quits application if escape is pressed
		if (Input.GetKey ("escape"))
			Application.Quit ();
		int walkTransition = 0;
		int turnSet = 0;
		// Stores the raw input from the right axis
		float input_x = Input.GetAxisRaw ("Horizontal");
		// Stores the raw input from the vertical axis
		float input_y = Input.GetAxisRaw ("Vertical");

			// Checks if left shift key is being held
			if (Input.GetKey (KeyCode.LeftShift)) {
				if (input_x == 1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}

				if (input_x == -1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}

				if (input_y == 1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}

				if (input_y == -1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}
			}

			// Checks if right shift is being held
			else if (Input.GetKey (KeyCode.RightShift)) {
				if (input_x == 1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}

				if (input_x == -1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}

				if (input_y == 1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}

				if (input_y == -1) {
					anim.SetFloat ("x", input_x);
					anim.SetFloat ("y", input_y);
				}
			}

			// Checks for right input
			else if (walkTransition == 0 && input_x == 1 && tr.position == pos) {
				walkTransition = 1;
				dir = 1;
				anim.SetFloat ("x", input_x);
				anim.SetFloat ("y", input_y);
				pos += Vector3.right;
				turnSet = 1;
				print (turnSet);

			}

			// Checks for left input
			else if (walkTransition == 0 && input_x == -1 && tr.position == pos) {
				walkTransition = 1;
				dir = 2;
				anim.SetFloat ("x", input_x);
				anim.SetFloat ("y", input_y);
				pos += Vector3.left;
			pTurn = false;
			
			}

			// Checks for up input
			else if (walkTransition == 0 && input_y == 1 && tr.position == pos) {
				walkTransition = 1;
				dir = 3;
				anim.SetFloat ("x", input_x);
				anim.SetFloat ("y", input_y);
				pos += Vector3.up;
				pTurn = false;

			}

			// Checks for down input
			else if (walkTransition == 0 && input_y == -1 && tr.position == pos) {
				walkTransition = 1;
				dir = 4;
				anim.SetFloat ("x", input_x);
				anim.SetFloat ("y", input_y);
				pos += Vector3.down;
				pTurn = false;
			}

			// Moves the player smoothly 1 whole unit
			transform.position = Vector3.MoveTowards (transform.position, pos, Time.deltaTime * speed);


	}

	//handles player collision with other objects with colliders
	//the player object will bounce from the other object and move back to it's original position
	void OnCollisionEnter2D()
	{
		if (dir == 1)
			pos += Vector3.left;
		else if (dir == 2)
			pos += Vector3.right;
		else if (dir == 3)
			pos += Vector3.down;
		else if (dir == 4)
			pos += Vector3.up;
	}

	void Enemy()
	{
		if (pTurn == false) {
		}
	}
}



