﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

namespace Completed
{
	using System.Collections.Generic;		//Allows us to use Lists. 
	using UnityEngine.UI;					//Allows us to use UI.
	
	public class GameManager : MonoBehaviour
	{
		public float levelStartDelay = 2f;						//Time to wait before starting level, in seconds.

		public static GameManager instance= null;				//Static instance of GameManager which allows it to be accessed by any other script.
		[HideInInspector] public bool playersTurn = true;		//Boolean to check if it's players turn, hidden in inspector but public.

		[HideInInspector]public int sceneNum;

		private Text fieldText1;
		private Text levelText;									//Text to display current level number.
		private GameObject levelImage;							//Image to block out level as levels are being set up, background for levelText.
		private int level = 1;									//Current level number, expressed in game as "Cursed Tower: Floor 1".

		//Awake is always called before any Start functions
		void Awake()
		{
			sceneNum = SceneManager.GetActiveScene ().buildIndex;
            //Check if instance already exists
            if (instance == null)

                //if not, set instance to this
                instance = this;

            //If instance already exists and it's not this:
            else if (instance != this)

                //Then destroy this. This enforces our singleton pattern, meaning there can only ever be one instance of a GameManager.
                Destroy(gameObject);
			
			//Sets this to not be destroyed when reloading scene
			//DontDestroyOnLoad(gameObject);
			
			//Call the InitGame function to initialize the first level 
			InitGame();
		}

//        //this is called only once, and the paramter tell it to be called only after the scene was loaded
//        //(otherwise, our Scene Load callback would be called the very first load, and we don't want that)
//        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
//        static public void CallbackInitialization()
//        {
//            //register the callback to be called everytime the scene is loaded
//            SceneManager.sceneLoaded += OnSceneLoaded;
//        }

//        //This is called each time a scene is loaded.
//		void OnLevelWasLoaded(int index)
//        {
//            level++;
//            InitGame();
//        }

		
		//Initializes the game for each level.
		void InitGame()
		{
			//Get a reference to our image LevelImage by finding it by name.
			levelImage = GameObject.Find("LevelImage");
			
			//Get a reference to our text LevelText's text component by finding it by name and calling GetComponent.
			levelText = GameObject.Find("LevelText").GetComponent<Text>();
			if (level == 1)
				levelText.text = "The Cursed Tower: Floor " + (sceneNum - 1);
			//Set the text of levelText to the string "The Cursed Tower: Floor" and append the current level number.
			else
				levelText.text = "The Cursed Tower: Floor " + (sceneNum - 1);

			fieldText1 = GameObject.Find("FloorNumText").GetComponent<Text>();
			fieldText1.text = "   Floor " + (sceneNum - 1);
			
			//Set levelImage to active blocking player's view of the game board during setup.
			levelImage.SetActive(true);
			
			//Call the HideLevelImage function with a delay in seconds of levelStartDelay.
			Invoke("HideLevelImage", levelStartDelay);

		}
		
		
		//Hides black image used between levels
		void HideLevelImage()
		{
			//Disable the levelImage gameObject.
			levelImage.SetActive(false);

		}
		
		//Update is called every frame.
		void Update()
		{

		}
		


		


	}
}

