﻿// This script checks if the object.Player Vector3 is equivalent to it's own Vector3
// If it is, bring up a selection for if the player wants to move to the next floor or not
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Staircase : MonoBehaviour {

	[HideInInspector]public int sceneNum;

	void Start(){
	// Get the scene number
	sceneNum = SceneManager.GetActiveScene().buildIndex;
	}

	// Update is called once per frame
	void Update () 
	{
		// Get the position of the player
		Vector3 playerPos = GameObject.Find ("Player(Clone)").transform.position;
		// Get the position of the Staircase
		Vector3 stairCase = transform.position;

		if (stairCase == playerPos) {
			if(Input.GetButton("Submit"))
				SceneManager.LoadScene (sceneNum + 1);
		}


	}
}
