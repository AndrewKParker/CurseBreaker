﻿using UnityEngine;
using System.Collections;

public class TargetFramerate : MonoBehaviour {
	void Start() {
		QualitySettings.vSyncCount = 1;
		Application.targetFrameRate = 60;
	}
}
